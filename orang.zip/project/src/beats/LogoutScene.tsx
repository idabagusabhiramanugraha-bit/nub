import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {BedroomScene} from '../components/BedroomScene';
import {Bubble} from '../components/Bubble';
import {Camera} from '../components/Camera';
import {LyingCharacter} from '../components/LyingCharacter';
import {Stage} from '../components/Stage';
import {clamp, usePop} from '../components/anim';
import {C} from '../styles/theme';

const Crown: React.FC<{x: number; y: number; s: number; rot: number}> = ({x, y, s, rot}) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`}>
    <path d="M-60,30 L-70,-30 L-30,0 L0,-45 L30,0 L70,-30 L60,30 Z" fill={C.yellow} stroke={C.outline} strokeWidth={7} strokeLinejoin="round" />
    <circle cx={0} cy={-45} r={9} fill="#fff" stroke={C.outline} strokeWidth={4} />
  </g>
);

const PowerIcon: React.FC<{x: number; y: number; at: number}> = ({x, y, at}) => {
  const p = usePop(at, 7);
  return (
    <g transform={`translate(${x},${y}) scale(${p})`}>
      <circle r={150} fill={C.red} stroke={C.outline} strokeWidth={10} />
      <path d="M-60,-70 A90,90 0 1 0 60,-70" fill="none" stroke="#fff" strokeWidth={22} strokeLinecap="round" />
      <line x1={0} y1={-120} x2={0} y2={-10} stroke="#fff" strokeWidth={22} strokeLinecap="round" />
    </g>
  );
};

/** BEAT 10 — Mental jagoan logout, klimaks (195 frame). "logout" diucapkan sekitar frame 180. */
export const LogoutScene: React.FC = () => {
  const f = useCurrentFrame();
  const lift = interpolate(f, [18, 45, 62], [0, -60, 0], clamp);
  const tiltTry = interpolate(f, [18, 45, 62], [0, -12, 0], clamp);
  const eyes = f > 80 ? 'tired' : 'weak';
  const crownY = interpolate(f, [100, 170], [820, 520], clamp);
  const crownOp = interpolate(f, [100, 112, 150, 176], [0, 1, 1, 0], clamp);
  const off = interpolate(f, [186, 194], [0, 0.6], clamp);
  return (
    <AbsoluteFill>
      <Camera
        kf={[
          {f: 0, z: 1.0, x: 540, y: 1000},
          {f: 50, z: 1.3, x: 500, y: 1020},
          {f: 168, z: 1.35, x: 500, y: 1030},
          {f: 190, z: 1.0, x: 540, y: 960},
          {f: 194, z: 1.0, x: 540, y: 960},
        ]}
      >
        <Stage>
          <BedroomScene stripes />
          <LyingCharacter
            cx={470}
            cy={1040}
            e={eyes === 'tired' ? 'tired' : 'weak'}
            blanketY={1160}
            tilt={-6 + tiltTry}
            headDy={lift}
            shiver={0.4}
            f={f}
            hand={{x: 800, y: 1150 + lift * 0.6}}
          />
          <g opacity={crownOp}>
            <Crown x={470} y={crownY} s={1.3} rot={-8 + Math.sin(f * 0.2) * 5} />
          </g>
          <PowerIcon x={790} y={560} at={180} />
        </Stage>
      </Camera>
      <Bubble x={90} y={270} w={900} h={220} at={182} variant="sticker" tail={null} fs={78} rot={-3}>
        MENTAL JAGOAN: <span style={{color: C.red}}>LOGOUT</span>
      </Bubble>
      <AbsoluteFill style={{background: '#000', opacity: off}} />
    </AbsoluteFill>
  );
};
