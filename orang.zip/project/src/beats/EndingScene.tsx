import React from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {BedroomScene} from '../components/BedroomScene';
import {BigText} from '../components/Bubble';
import {Camera} from '../components/Camera';
import {Star} from '../components/FX';
import {LyingCharacter} from '../components/LyingCharacter';
import {MainCharacter, POSES, lerpPose} from '../components/MainCharacter';
import {Stage} from '../components/Stage';
import {seg, usePop, wob} from '../components/anim';
import {C} from '../styles/theme';

const Sunburst: React.FC<{f: number}> = ({f}) => (
  <g>
    <rect x={-400} y={-400} width={1880} height={2700} fill="#FFD23F" />
    <g transform={`rotate(${f * 0.6} 540 900)`}>
      {Array.from({length: 16}).map((_, i) => {
        const a1 = (i / 16) * Math.PI * 2;
        const a2 = ((i + 0.5) / 16) * Math.PI * 2;
        return (
          <polygon
            key={i}
            points={`540,900 ${540 + Math.cos(a1) * 2600},${900 + Math.sin(a1) * 2600} ${540 + Math.cos(a2) * 2600},${900 + Math.sin(a2) * 2600}`}
            fill="#FFE98A"
          />
        );
      })}
    </g>
  </g>
);

const Stars: React.FC = () => (
  <g>
    <Star x={170} y={560} s={42} at={14} />
    <Star x={900} y={520} s={34} at={16} phase={1} fill="#fff" />
    <Star x={120} y={980} s={26} at={18} phase={2} fill="#fff" />
    <Star x={950} y={1000} s={40} at={20} phase={3} />
    <Star x={820} y={300} s={28} at={22} phase={4} fill="#fff" />
  </g>
);

const Heart: React.FC<{x: number; y: number}> = ({x, y}) => {
  const p = usePop(2);
  return (
    <g transform={`translate(${x},${y}) scale(${p * 2.2})`}>
      <path d="M0,22 C-40,-6 -26,-36 0,-18 C26,-36 40,-6 0,22 Z" fill={C.red} stroke={C.outline} strokeWidth={4} strokeLinejoin="round" />
    </g>
  );
};

/** BEAT 11 — Kembali percaya diri (54 frame). Panel 11 jadi 12 frame pembuka, lalu smash cut. */
const Back: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (f < 12) {
    return (
      <AbsoluteFill>
        <Stage>
          <BedroomScene stripes />
          <LyingCharacter cx={470} cy={1040} e="tired" blush blanketY={1150} tilt={-6} f={f} />
          <Heart x={800} y={900} />
        </Stage>
      </AbsoluteFill>
    );
  }
  const g = f - 12;
  const sp = spring({frame: g, fps, config: {damping: 7, stiffness: 190, mass: 0.5}});
  const sy = 0.8 + 0.2 * sp;
  const sx = 1 + (1 - sy) * 0.5;
  const pose = lerpPose(lerpPose(POSES.stand, POSES.adjust, seg(g, 2, 14)), POSES.pointUp, seg(g, 20, 30));
  return (
    <AbsoluteFill>
      <Camera
        kf={[{f: 0, z: 1.0}, {f: 11, z: 1.0}, {f: 12, z: 1.45, x: 540, y: 900}, {f: 30, z: 1.0, x: 540, y: 960}]}
        shake={{at: 12, amp: 14, len: 10}}
      >
        <Stage>
          <Sunburst f={f} />
          <Stars />
          <MainCharacter x={540} y={1320} scale={1.25} sx={sx} sy={sy} pose={pose} expression="smug" shades finger={g > 26 ? 'point' : null} headTilt={seg(g, 10, 26) * 5} />
        </Stage>
      </Camera>
    </AbsoluteFill>
  );
};

/** BEAT 12 — Ending komedi, tertawa + freeze frame (54 frame). */
const End: React.FC = () => {
  const real = useCurrentFrame();
  const f = Math.min(real, 41); // freeze 12 frame terakhir
  return (
    <AbsoluteFill>
      <Camera kf={[{f: 0, z: 1.0, x: 540, y: 900}, {f: 41, z: 1.1, x: 540, y: 900}]}>
        <Stage>
          <Sunburst f={f + 54} />
          <Stars />
          <MainCharacter
            x={540}
            y={1320}
            scale={1.25}
            pose={POSES.pointUp}
            expression="laugh"
            shades
            finger="point"
            talk={0.5 + 0.5 * Math.sin(f * 1.3)}
            rot={wob(f, 1.0, 3)}
            headDy={wob(f, 1.3, 6)}
            headTilt={wob(f, 0.9, 5)}
          />
        </Stage>
      </Camera>
      <BigText x={90} y={260} w={900} at={2} fs={158} color="#fff" rot={-6}>HAHAHA!</BigText>
    </AbsoluteFill>
  );
};

export const EndingScene: React.FC<{part: 'back' | 'end'}> = ({part}) => (part === 'back' ? <Back /> : <End />);
