import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {BedroomScene} from '../components/BedroomScene';
import {Camera} from '../components/Camera';
import {Star} from '../components/FX';
import {LyingCharacter} from '../components/LyingCharacter';
import {MainCharacter, POSES} from '../components/MainCharacter';
import {RoadScene} from '../components/RoadScene';
import {Stage} from '../components/Stage';
import {clamp, wob} from '../components/anim';
import {C, FONT} from '../styles/theme';

const TOP = '0,0 1080,0 1080,720 0,860';
const BOTTOM = '0,860 1080,720 1080,1920 0,1920';

const Motor: React.FC<{x: number; g: number}> = ({x, g}) => {
  const o = C.outline;
  return (
    <g transform={`translate(${x},${g})`}>
      <circle cx={-120} cy={-70} r={70} fill="#2B2B33" stroke={o} strokeWidth={8} />
      <circle cx={-120} cy={-70} r={30} fill="#9AA0AE" stroke={o} strokeWidth={5} />
      <circle cx={150} cy={-70} r={70} fill="#2B2B33" stroke={o} strokeWidth={8} />
      <circle cx={150} cy={-70} r={30} fill="#9AA0AE" stroke={o} strokeWidth={5} />
      <path d="M-120,-70 L-40,-150 L80,-150 L150,-70" fill="none" stroke={o} strokeWidth={22} strokeLinejoin="round" />
      <path d="M-40,-150 L90,-150 L110,-190 L-30,-195 Z" fill="#B8323C" stroke={o} strokeWidth={7} strokeLinejoin="round" />
      <path d="M-70,-170 Q-20,-200 40,-175 L40,-150 L-70,-150 Z" fill={o} />
      <path d="M110,-190 L135,-240 L175,-232" fill="none" stroke={o} strokeWidth={12} strokeLinecap="round" />
      <path d="M-130,-110 L-210,-100" stroke="#9AA0AE" strokeWidth={14} strokeLinecap="round" />
    </g>
  );
};

/** BEAT 07 — Kontras kemarin vs sekarang, split diagonal + efek rewind (84 frame). */
export const FlashbackScene: React.FC = () => {
  const f = useCurrentFrame();
  const bob = wob(f, 0.9, 6);
  const rewind = f < 18;
  return (
    <AbsoluteFill>
      <Camera
        kf={[
          {f: 0, z: 1.25, x: 540, y: 520},
          {f: 30, z: 1.25, x: 540, y: 520},
          {f: 48, z: 1.12, x: 540, y: 1040},
          {f: 83, z: 1.12, x: 540, y: 1060},
        ]}
      >
        <Stage>
          <defs>
            <clipPath id="cpTop"><polygon points={TOP} /></clipPath>
            <clipPath id="cpBottom"><polygon points={BOTTOM} /></clipPath>
          </defs>
          <g clipPath="url(#cpTop)">
            <g transform="translate(0,-480)">
              <RoadScene t={f * 3} />
            </g>
            <g transform="translate(0,-480)">
              <Motor x={470} g={1260 + bob * 0.3} />
              <MainCharacter
                x={500}
                y={1260 - 48 + bob * 0.3}
                scale={0.5}
                pose={POSES.ride}
                expression="laugh"
                shades
                talk={0.5 + 0.5 * Math.sin(f * 1.2)}
                shadow={false}
                headTilt={wob(f, 0.8, 4)}
              />
            </g>
            <Star x={250} y={330} s={30} at={20} />
            <Star x={860} y={300} s={26} at={24} phase={2} />
            <Star x={760} y={560} s={20} at={28} phase={4} />
          </g>
          <g clipPath="url(#cpBottom)">
            <BedroomScene stripes />
            <LyingCharacter cx={540} cy={1090} sc={0.9} e="tired" blanketY={1190} tilt={-6} shiver={1} f={f} />
          </g>
          <line x1={0} y1={860} x2={1080} y2={720} stroke="#fff" strokeWidth={16} />
          <line x1={0} y1={860} x2={1080} y2={720} stroke={C.outline} strokeWidth={4} />
        </Stage>
      </Camera>
      {rewind ? (
        <AbsoluteFill>
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <div
              key={i}
              style={{
                position: 'absolute',
                left: 0,
                width: 1080,
                height: 38,
                top: ((f * 90 + i * 330) % 1920) - 40,
                background: 'rgba(255,255,255,0.22)',
              }}
            />
          ))}
          <div
            style={{
              position: 'absolute',
              left: 70,
              top: 250,
              fontFamily: FONT,
              fontWeight: 900,
              fontSize: 120,
              color: '#fff',
              textShadow: `0 0 0 ${C.outline}, -5px -5px 0 ${C.outline}, 5px 5px 0 ${C.outline}, 5px -5px 0 ${C.outline}, -5px 5px 0 ${C.outline}`,
              opacity: interpolate(f, [0, 14, 18], [1, 1, 0], clamp),
            }}
          >
            ◀◀
          </div>
        </AbsoluteFill>
      ) : null}
    </AbsoluteFill>
  );
};
