import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Camera} from '../components/Camera';
import {Star} from '../components/FX';
import {MainCharacter, POSES, lerpPose} from '../components/MainCharacter';
import {Stage} from '../components/Stage';
import {BigText} from '../components/Bubble';
import {clamp, seg, usePop} from '../components/anim';
import {C, FONT} from '../styles/theme';

const o = C.outline;

const Halftone: React.FC = () => (
  <g>
    <defs>
      <linearGradient id="yelG" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#FFD54A" />
        <stop offset="1" stopColor="#FF9F1C" />
      </linearGradient>
      <pattern id="dots" width="44" height="44" patternUnits="userSpaceOnUse">
        <circle cx="22" cy="22" r="6" fill="#FFB703" opacity="0.7" />
      </pattern>
    </defs>
    <rect x={-400} y={-400} width={1880} height={2700} fill="url(#yelG)" />
    <rect x={-400} y={-400} width={1880} height={2700} fill="url(#dots)" />
  </g>
);

const Label: React.FC<{cx: number; y: number; lines: string[]; fs: number}> = ({cx, y, lines, fs}) => (
  <g>
    {lines.map((t, i) => (
      <text key={i} x={cx} y={y + i * (fs + 4)} textAnchor="middle" fontFamily={FONT} fontWeight={900} fontSize={fs} fill={i === 0 ? C.red : o}>
        {t}
      </text>
    ))}
  </g>
);

const Panel: React.FC<{x: number; y: number; w: number; h: number; at: number; children?: React.ReactNode}> = ({x, y, w, h, at, children}) => {
  const p = usePop(at);
  const cx = x + w / 2;
  const cy = y + h / 2;
  if (p <= 0.001) return null;
  return (
    <g transform={`translate(${cx},${cy}) scale(${p}) translate(${-cx},${-cy})`}>
      <rect x={x} y={y} width={w} height={h} rx={70} fill="#fff" stroke={o} strokeWidth={8} />
      {children}
    </g>
  );
};

const Ache: React.FC<{x: number; y: number; phase: number; at: number}> = ({x, y, phase, at}) => {
  const f = useCurrentFrame();
  const p = usePop(at);
  const k = 1 + 0.2 * Math.sin(f * 0.5 + phase);
  return (
    <g transform={`translate(${x},${y}) scale(${p * k})`} stroke={C.red} strokeWidth={7} strokeLinecap="round" fill="none">
      <path d="M-22,-8 L-8,-22 L0,-6 L12,-24 L24,-8" />
      <path d="M-22,12 L-8,-2 L0,14 L12,-4 L24,12" />
    </g>
  );
};

/** BEAT 09 — Penjelasan kenapa (315 frame). */
export const ExplanationScene: React.FC = () => {
  const f = useCurrentFrame();
  const p1 = lerpPose(POSES.think, POSES.pointUp, seg(f, 10, 22));
  const p2 = lerpPose(p1, POSES.think, seg(f, 60, 75));
  const nod = f > 285 ? Math.sin((f - 285) * 0.7) * 7 : 0;
  const ring = f * 6;
  return (
    <AbsoluteFill>
      <Camera
        kf={[
          {f: 0, z: 1.0, x: 540, y: 960},
          {f: 60, z: 1.0, x: 540, y: 960},
          {f: 85, z: 1.3, x: 760, y: 470},
          {f: 165, z: 1.3, x: 760, y: 470},
          {f: 195, z: 1.25, x: 760, y: 960},
          {f: 265, z: 1.25, x: 760, y: 960},
          {f: 295, z: 1.0, x: 540, y: 960},
          {f: 314, z: 1.0, x: 540, y: 960},
        ]}
      >
        <Stage>
          <Halftone />
          <MainCharacter x={250} y={1330} scale={0.8} pose={p2} expression="think" finger={f >= 22 && f < 70 ? 'point' : null} headTilt={nod} />
          <Star x={470} y={880} s={26} at={90} />
          {/* ilustrasi luka */}
          <Panel x={520} y={250} w={480} h={390} at={75}>
            <path d="M590,430 L750,420" stroke={o} strokeWidth={24} strokeLinecap="round" />
            <path d="M750,420 L830,520" stroke={o} strokeWidth={24} strokeLinecap="round" />
            <ellipse cx={850} cy={538} rx={44} ry={18} fill={o} />
            <circle cx={750} cy={420} r={32} fill="#fff" stroke={o} strokeWidth={4} />
            <path d="M738,408 L762,432 M748,402 L768,424" stroke={C.blood} strokeWidth={6} strokeLinecap="round" />
            <path d="M760,436 Q776,462 760,470 Q744,462 760,436 Z" fill={C.blood} stroke={o} strokeWidth={3} />
            <circle cx={750} cy={420} r={60} fill="none" stroke={C.red} strokeWidth={8} strokeDasharray="22 14" strokeDashoffset={-ring} />
            <Label cx={760} y={585} lines={['LUKA:', 'SAKIT DI SATU BAGIAN']} fs={32} />
          </Panel>
          {/* ilustrasi demam */}
          <Panel x={470} y={690} w={560} h={560} at={178}>
            <MainCharacter x={750} y={1150} scale={0.5} pose={POSES.stand} expression="sick" blush thermo shadow={false} headTilt={wob2(f)} />
            <Ache x={668} y={955} phase={0} at={200} />
            <Ache x={832} y={955} phase={1} at={210} />
            <Ache x={750} y={1040} phase={2} at={220} />
            <Ache x={700} y={1130} phase={3} at={230} />
            <Ache x={800} y={1130} phase={4} at={240} />
            <Ache x={690} y={1070} phase={5} at={250} />
            <path d="M560,850 q-16,22 0,44 M540,850 q-16,22 0,44 M940,850 q16,22 0,44 M960,850 q16,22 0,44" stroke={C.blanketHi} strokeWidth={7} fill="none" strokeLinecap="round" />
            <Label cx={750} y={1200} lines={['DEMAM:', 'SELURUH BADAN TERASA REMUK']} fs={28} />
          </Panel>
        </Stage>
      </Camera>
      <QuestionMark />
    </AbsoluteFill>
  );
};

const wob2 = (f: number): number => Math.sin(f * 1.4) * 4;

const QuestionMark: React.FC = () => {
  const f = useCurrentFrame();
  const op = interpolate(f, [0, 60, 75], [1, 1, 0], clamp);
  return (
    <div style={{opacity: op}}>
      <BigText x={330} y={620} w={200} at={12} fs={170} color={o} rot={10}>?</BigText>
    </div>
  );
};
