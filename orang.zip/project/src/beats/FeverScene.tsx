import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {BedroomScene} from '../components/BedroomScene';
import {Camera} from '../components/Camera';
import {LyingCharacter} from '../components/LyingCharacter';
import {Stage} from '../components/Stage';
import {seg} from '../components/anim';

/** BEAT 04 — Tiba-tiba demam, termometer di mulut (63 frame). */
export const FeverScene: React.FC = () => {
  const f = useCurrentFrame();
  const therm = seg(f, 6, 14) > 0.5;
  return (
    <AbsoluteFill>
      <Camera kf={[{f: 0, z: 1.7, x: 520, y: 1030}, {f: 14, z: 1.2, x: 520, y: 1040}, {f: 62, z: 1.28, x: 520, y: 1050}]}>
        <Stage>
          <BedroomScene stripes />
          <LyingCharacter cx={470} cy={1040} e="sick" blanketY={1300} tilt={-6} shiver={1.5} f={f} thermo={therm} />
        </Stage>
      </Camera>
    </AbsoluteFill>
  );
};
