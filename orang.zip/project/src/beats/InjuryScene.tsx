import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {Bubble} from '../components/Bubble';
import {Camera} from '../components/Camera';
import {Dust, Star, SweatDrop} from '../components/FX';
import {MainCharacter, POSES, lerpPose} from '../components/MainCharacter';
import {RoadScene} from '../components/RoadScene';
import {Stage} from '../components/Stage';
import {clamp, seg} from '../components/anim';
import {C} from '../styles/theme';

const IMPACT = 22;
const SIT_SCALE = 1.2;

/** BEAT 02 — Jatuh (90 frame). */
const Fall: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  let body: React.ReactNode;
  if (f < IMPACT) {
    const rot = interpolate(f, [0, 7, IMPACT], [0, -10, 82], {...clamp, easing: Easing.in(Easing.quad)});
    const x = interpolate(f, [0, IMPACT], [280, 440], clamp);
    const y = interpolate(f, [0, 9, IMPACT], [1320, 1275, 1330], clamp);
    body = <MainCharacter x={x} y={y} rot={rot} scale={1.2} pose={POSES.flail} expression="shock" />;
  } else {
    const g = f - IMPACT;
    const sp = spring({frame: g, fps, config: {damping: 6, stiffness: 200, mass: 0.5}});
    const sy = interpolate(sp, [0, 1], [0.7, 1]);
    const sx = 1 + (1 - sy) * 0.6;
    const struggle = interpolate(f, [50, 62, 75, 89], [0, -6, 0, -3], clamp);
    body = (
      <>
        <ellipse cx={520} cy={1338} rx={300} ry={24} fill="#000" opacity={0.2} />
        <MainCharacter
          x={440}
          y={1330 + 190 * SIT_SCALE}
          scale={SIT_SCALE}
          sx={sx}
          sy={sy}
          rot={struggle}
          pose={POSES.sit}
          expression="pain"
          wound="L"
          shadow={false}
          headTilt={interpolate(f, [30, 60], [0, 8], clamp)}
        />
      </>
    );
  }
  return (
    <AbsoluteFill>
      <Camera
        kf={[
          {f: 0, z: 1.05, x: 540, y: 1050, r: 0},
          {f: IMPACT, z: 1.18, x: 520, y: 1120, r: -2},
          {f: 89, z: 1.25, x: 500, y: 1100, r: -3},
        ]}
        shake={{at: IMPACT, amp: 18, len: 12}}
      >
        <Stage>
          <RoadScene t={f + 30} />
          {body}
          <Dust x={560} y={1330} at={IMPACT} />
          <Dust x={300} y={1330} at={IMPACT + 2} />
          <Star x={470} y={1050} s={44} at={IMPACT} fill="#fff" />
          <Star x={640} y={1010} s={30} at={IMPACT + 2} />
          {f >= IMPACT + 6 ? <SweatDrop x={330} y={900} at={IMPACT + 6} /> : null}
          {f < IMPACT ? (
            <g stroke="#fff" strokeWidth={7} strokeLinecap="round" opacity={0.8}>
              <path d="M150,950 L300,950" />
              <path d="M120,1050 L260,1050" />
              <path d="M170,1150 L290,1150" />
            </g>
          ) : null}
        </Stage>
      </Camera>
    </AbsoluteFill>
  );
};

/** BEAT 03 — Sok kuat (63 frame). */
const Stand: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sp = spring({frame: f, fps, config: {damping: 7, stiffness: 180, mass: 0.5}});
  const sy = 0.82 + 0.18 * sp;
  const sx = 1 + (1 - sy) * 0.5;
  const p1 = lerpPose(POSES.rise, POSES.headHand, seg(f, 6, 18));
  const p2 = lerpPose(p1, POSES.thumbs, seg(f, 32, 44));
  return (
    <AbsoluteFill>
      <Camera kf={[{f: 0, z: 1.1, x: 540, y: 1050}, {f: 40, z: 1.0, x: 540, y: 960}]}>
        <Stage>
          <RoadScene t={f + 120} />
          <MainCharacter
            x={540}
            y={1320}
            scale={1.2}
            sx={sx}
            sy={sy}
            pose={p2}
            expression={f < 6 ? 'pain' : 'smug'}
            finger={f > 36 ? 'thumb' : null}
            wound="R"
            headTilt={interpolate(f, [14, 30], [0, 5], clamp)}
          />
          <SweatDrop x={760} y={700} at={12} />
          <SweatDrop x={800} y={760} at={16} />
          <Star x={300} y={690} s={34} at={10} />
          <Star x={820} y={560} s={26} at={14} phase={2} />
          <Star x={250} y={820} s={20} at={18} phase={4} />
        </Stage>
        <Bubble x={120} y={230} w={840} h={290} at={8} variant="burst" fs={62}>
          <span style={{color: C.outline}}>AH, SANTAI, NGGAK SAKIT!</span>
        </Bubble>
      </Camera>
    </AbsoluteFill>
  );
};

export const InjuryScene: React.FC<{part: 'fall' | 'stand'}> = ({part}) => (part === 'fall' ? <Fall /> : <Stand />);
