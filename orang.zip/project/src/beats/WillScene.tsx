import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {BedroomScene} from '../components/BedroomScene';
import {BigText, Bubble} from '../components/Bubble';
import {Camera} from '../components/Camera';
import {SpeedLines} from '../components/FX';
import {LyingCharacter} from '../components/LyingCharacter';
import {Stage} from '../components/Stage';
import {clamp, usePop, wob} from '../components/anim';
import {C, FONT} from '../styles/theme';

/** BEAT 06 — Drama "umurku nggak panjang lagi" (111 frame). */
const Umur: React.FC = () => {
  const f = useCurrentFrame();
  const talking = f >= 6 && f < 90;
  const talk = talking ? 0.5 + 0.5 * Math.sin(f * 1.1) : 0.2;
  const fall = interpolate(f, [88, 104], [0, 1], clamp);
  const handLift = interpolate(f, [18, 46, 62], [0, -80, 0], clamp);
  return (
    <AbsoluteFill>
      <Camera kf={[{f: 0, z: 1.15, x: 520, y: 1010, r: 0}, {f: 110, z: 1.35, x: 500, y: 1030, r: -5}]}>
        <Stage>
          <BedroomScene stripes />
          <LyingCharacter
            cx={470}
            cy={1040}
            e="dying"
            talk={talk}
            blanketY={1140 + fall * 8}
            tilt={interpolate(fall, [0, 1], [-6, 10])}
            headDy={fall * 30}
            shiver={0.5}
            f={f}
            hand={{x: 830, y: 1135 + handLift}}
          />
        </Stage>
      </Camera>
      <Bubble x={100} y={250} w={880} h={320} at={8} tail="down" tailPos={55} fs={64}>
        KAYAKNYA UMURKU NGGAK PANJANG LAGI.
      </Bubble>
    </AbsoluteFill>
  );
};

const Letter: React.FC<{x: number; y: number; rot: number}> = ({x, y, rot}) => (
  <g transform={`translate(${x},${y}) rotate(${rot})`}>
    <rect x={-190} y={-140} width={380} height={280} fill="#F7F2E2" stroke={C.outline} strokeWidth={8} />
    <path d="M-190,-140 L0,-20 L190,-140" fill="none" stroke="#D8CFB4" strokeWidth={5} />
    <text x={0} y={-5} textAnchor="middle" fontFamily={FONT} fontWeight={900} fontSize={66} fill={C.outline}>SURAT</text>
    <text x={0} y={70} textAnchor="middle" fontFamily={FONT} fontWeight={900} fontSize={66} fill={C.outline}>WASIAT</text>
    <circle cx={150} cy={125} r={27} fill={C.outline} />
  </g>
);

/** BEAT 08 — Surat wasiat (108 frame). */
const Surat: React.FC = () => {
  const f = useCurrentFrame();
  const rise = interpolate(f, [4, 30], [0, 1], clamp);
  const lx = 700;
  const ly = 1320 - rise * 230 + wob(f, 1.9, 4);
  const lrot = -8 + wob(f, 2.3, 3);
  const talk = 0.5 + 0.5 * Math.sin(f * 0.9);
  const pop = usePop(40);
  return (
    <AbsoluteFill>
      <Camera
        kf={[
          {f: 0, z: 2.0, x: 700, y: 1180},
          {f: 28, z: 2.0, x: 700, y: 1150},
          {f: 46, z: 1.15, x: 560, y: 1020},
          {f: 107, z: 1.2, x: 560, y: 1020},
        ]}
      >
        <Stage>
          <BedroomScene stripes />
          <LyingCharacter cx={450} cy={1040} e="shock" talk={talk} blanketY={1150} tilt={-4 + wob(f, 1.7, 2)} shiver={1} f={f} hand={{x: lx + 150, y: ly + 125}}>
            <Letter x={lx} y={ly} rot={lrot} />
            <circle cx={lx + 150} cy={ly + 125} r={27} fill={C.outline} />
          </LyingCharacter>
          {f >= 40 ? (
            <g opacity={pop}>
              <SpeedLines cx={450} cy={1040} r0={330} r1={520} count={20} />
            </g>
          ) : null}
        </Stage>
      </Camera>
      <BigText x={640} y={330} w={340} at={40} fs={190} color={C.red} rot={8}>!!!</BigText>
    </AbsoluteFill>
  );
};

export const WillScene: React.FC<{part: 'umur' | 'surat'}> = ({part}) => (part === 'umur' ? <Umur /> : <Surat />);
