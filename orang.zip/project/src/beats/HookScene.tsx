import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Bubble} from '../components/Bubble';
import {Camera} from '../components/Camera';
import {MainCharacter, POSES} from '../components/MainCharacter';
import {RoadScene} from '../components/RoadScene';
import {Stage} from '../components/Stage';
import {clamp, usePop} from '../components/anim';
import {C} from '../styles/theme';

/** BEAT 01 — Hook pertanyaan (60 frame). */
export const HookScene: React.FC = () => {
  const f = useCurrentFrame();
  const tilt = interpolate(f, [0, 14, 30], [0, -7, -4], clamp);
  const pop = usePop(14);
  return (
    <AbsoluteFill>
      <Camera kf={[{f: 0, z: 1.0, x: 540, y: 960}, {f: 10, z: 1.02, x: 540, y: 960}, {f: 45, z: 1.15, x: 540, y: 920}]}>
        <Stage>
          <RoadScene t={f} blur />
          <rect x={-400} y={-400} width={1880} height={2700} fill="#1B2A4A" opacity={0.18} />
          <MainCharacter x={430} y={1320} scale={1.2} pose={POSES.think} expression="think" headTilt={tilt} />
          <g stroke={C.yellow} strokeWidth={14} strokeLinecap="round" transform={`scale(${pop})`} style={{transformOrigin: '900px 220px'}}>
            <path d="M858,250 L895,200" />
            <path d="M900,262 L945,222" />
            <path d="M880,214 L902,176" />
          </g>
        </Stage>
        <Bubble x={90} y={240} w={900} h={320} at={14} tail="down" tailPos={22} fs={74}>
          KENAPA COWOK LEBIH TAHAN <span style={{color: C.red}}>TERLUKA</span> DARIPADA TAHAN <span style={{color: C.red}}>DEMAM</span>?
        </Bubble>
      </Camera>
    </AbsoluteFill>
  );
};
