import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {BedroomScene} from '../components/BedroomScene';
import {Camera} from '../components/Camera';
import {HeatLines, Steam} from '../components/FX';
import {LyingCharacter} from '../components/LyingCharacter';
import {Stage} from '../components/Stage';
import {clamp} from '../components/anim';

/** BEAT 05 — Manja saat demam, selimutan sampai kepala (183 frame). */
export const BlanketScene: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sp = f < 20 ? 0 : spring({frame: f - 20, fps, config: {damping: 10, stiffness: 90, mass: 0.9}});
  const by = interpolate(sp, [0, 1], [1300, 1140]);
  const dy = interpolate(sp, [0, 1], [0, 40]);
  const breathe = 0.5 + 0.5 * Math.sin(f * 0.22);
  return (
    <AbsoluteFill>
      <Camera kf={[{f: 0, z: 1.0, x: 540, y: 1000}, {f: 182, z: 1.28, x: 520, y: 1050}]}>
        <Stage>
          <BedroomScene stripes />
          <LyingCharacter cx={470} cy={1040} e="weak" talk={breathe} blanketY={by} headDy={dy} tilt={interpolate(f, [20, 70], [-6, -9], clamp)} shiver={sp * 1.2 + 0.3} f={f} />
          <Steam x={190} y={980} />
          <HeatLines x={800} y={1010} />
        </Stage>
      </Camera>
    </AbsoluteFill>
  );
};
