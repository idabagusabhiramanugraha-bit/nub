import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {BEATS, HAS_AUDIO} from './data/beats';
import {BlanketScene} from './beats/BlanketScene';
import {EndingScene} from './beats/EndingScene';
import {ExplanationScene} from './beats/ExplanationScene';
import {FeverScene} from './beats/FeverScene';
import {FlashbackScene} from './beats/FlashbackScene';
import {HookScene} from './beats/HookScene';
import {InjuryScene} from './beats/InjuryScene';
import {LogoutScene} from './beats/LogoutScene';
import {WillScene} from './beats/WillScene';
import {SoundEffects} from './components/SoundEffects';
import {Subtitle} from './components/Subtitle';
import {Transitions} from './components/Transitions';

const Beat02: React.FC = () => <InjuryScene part="fall" />;
const Beat03: React.FC = () => <InjuryScene part="stand" />;
const Beat06: React.FC = () => <WillScene part="umur" />;
const Beat08: React.FC = () => <WillScene part="surat" />;
const Beat11: React.FC = () => <EndingScene part="back" />;
const Beat12: React.FC = () => <EndingScene part="end" />;

const SCENES: Record<number, React.FC> = {
  1: HookScene,
  2: Beat02,
  3: Beat03,
  4: FeverScene,
  5: BlanketScene,
  6: Beat06,
  7: FlashbackScene,
  8: Beat08,
  9: ExplanationScene,
  10: LogoutScene,
  11: Beat11,
  12: Beat12,
};

/** Video utama. Tanpa header, tanpa progress bar: seluruh layar untuk cerita. */
export const Video: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#000', overflow: 'hidden'}}>
    {HAS_AUDIO ? <Audio src={staticFile('narasi.mp3')} /> : null}
    {BEATS.map((b) => {
      const Scene = SCENES[b.id];
      return (
        <Sequence key={b.id} from={b.from} durationInFrames={b.dur} name={`Beat ${String(b.id).padStart(2, '0')} - ${b.title}`}>
          <Scene />
        </Sequence>
      );
    })}
    <Transitions />
    <Subtitle />
    <SoundEffects />
  </AbsoluteFill>
);
