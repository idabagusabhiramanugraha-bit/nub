import React from 'react';
import {Composition} from 'remotion';
import {TOTAL_FRAMES} from './data/beats';
import {FPS, H, W} from './data/layout';
import {Video} from './Video';

export const RemotionRoot: React.FC = () => (
  <Composition id="Cerita" component={Video} durationInFrames={TOTAL_FRAMES} fps={FPS} width={W} height={H} />
);
