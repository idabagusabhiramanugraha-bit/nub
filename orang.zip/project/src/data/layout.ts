export const W = 1080;
export const H = 1920;
export const FPS = 30;

export type Rect = {x: number; y: number; w: number; h: number};

/** Area aman untuk UI Shorts / TikTok / Reels. */
export const SAFE: Rect = {x: 60, y: 220, w: 900, h: 1280};

/** Tabel koordinat Fase 1 (kanvas 1080x1920, origin kiri-atas). */
export const LAYOUT = {
  subtitle: {x: 60, y: 1340, w: 840, h: 220} as Rect,
  b01: {
    karakter: {x: 200, y: 640, w: 680, h: 800} as Rect,
    judul: {x: 90, y: 240, w: 900, h: 400} as Rect,
  },
  b02: {
    karakterJatuh: {x: 100, y: 720, w: 880, h: 640} as Rect,
    lukaLutut: {x: 520, y: 1040, w: 160, h: 160} as Rect,
  },
  b03: {
    karakter: {x: 240, y: 640, w: 600, h: 700} as Rect,
    dialog: {x: 90, y: 260, w: 900, h: 300} as Rect,
  },
  b04: {
    tempatTidur: {x: 0, y: 760, w: 1080, h: 700} as Rect,
    termometer: {x: 560, y: 1010, w: 260, h: 70} as Rect,
  },
  b05: {selimut: {x: 0, y: 900, w: 1080, h: 600} as Rect},
  b06: {bubbleUmur: {x: 100, y: 260, w: 880, h: 320} as Rect},
  b08: {
    suratWasiat: {x: 560, y: 1000, w: 380, h: 300} as Rect,
    tandaSeru: {x: 700, y: 360, w: 200, h: 240} as Rect,
  },
  b09: {
    ilustrasiLuka: {x: 520, y: 250, w: 480, h: 390} as Rect,
    ilustrasiDemam: {x: 470, y: 690, w: 560, h: 560} as Rect,
    karakterBerpikir: {x: 60, y: 880, w: 460, h: 450} as Rect,
  },
  b10: {
    ikonLogout: {x: 640, y: 410, w: 300, h: 300} as Rect,
    teksLogout: {x: 90, y: 280, w: 900, h: 200} as Rect,
  },
  b11: {karakterKacamata: {x: 220, y: 560, w: 640, h: 820} as Rect},
  b12: {teksHaha: {x: 90, y: 260, w: 900, h: 300} as Rect},
};
