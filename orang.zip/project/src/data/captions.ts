import {FPS} from './layout';

/**
 * Satu-satunya offset sinkronisasi subtitle (detik).
 * Positif = subtitle muncul lebih lambat, negatif = lebih cepat.
 */
export const AUDIO_OFFSET = 0;

/**
 * TIMING SEMENTARA: waktu per kata dibagi proporsional jumlah karakter di dalam
 * tiap blok SRT. Setelah narasi.mp3 final, ganti SRT_RAW dengan SRT hasil
 * transkripsi audio (atau tambahkan AUDIO_OFFSET) agar sinkron persis.
 */
export const CAPTION_TIMING_PROVISIONAL = true;

export const SRT_RAW = `1
00:00:00,100 --> 00:00:04,960
Pernah enggak sih lihat cowok jatuh sampai
lutut berdarah tapi masih bisa bilang,

2
00:00:04,960 --> 00:00:11,300
"Ah, santai, enggak sakit." Tapi coba
kasih dia demam sedikit aja. Baru badan

3
00:00:11,300 --> 00:00:17,020
anget dikit, langsung rebahan, selimutan
sampai kepala, terus ngomong, "Kayaknya

4
00:00:17,020 --> 00:00:18,380
umurku enggak panjang lagi."

5
00:00:19,000 --> 00:00:23,620
Lah, kemarin jatuh dari motor masih bisa
ketawa. Sekarang pilek dikit udah kayak

6
00:00:23,620 --> 00:00:29,620
mau bikin surat wasiat. Tapi kenapa bisa
begitu? Soalnya luka biasanya cuma sakit

7
00:00:29,620 --> 00:00:34,860
di satu bagian, sedangkan demam bikin
seluruh badan terasa remuk, lemas, dan

8
00:00:34,860 --> 00:00:40,140
enggak nyaman. Jadi, cowok itu bukan
enggak takut sakit, cuma kalau demam,

9
00:00:40,140 --> 00:00:42,420
mental jagoannya langsung lock out.`;

export type CapWord = {text: string; start: number; end: number; key: boolean};
export type CapChunk = {start: number; end: number; words: CapWord[]};

/** timestamp (detik) -> frame, sesuai aturan Math.round(timestamp * fps) */
export const toFrame = (t: number): number => Math.round((t + AUDIO_OFFSET) * FPS);

const toSec = (s: string): number => {
  const m = /(\d+):(\d+):(\d+),(\d+)/.exec(s);
  if (!m) return 0;
  return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) + Number(m[4]) / 1000;
};

/** Ejaan tampilan mengikuti naskah final: "nggak" dan "logout". */
const normalize = (t: string): string =>
  t
    .replace(/\s+/g, ' ')
    .replace(/\benggak\b/gi, 'nggak')
    .replace(/lock out/gi, 'logout')
    .trim();

const KEYWORDS = new Set([
  'demam', 'luka', 'berdarah', 'sakit', 'santai', 'surat', 'wasiat', 'logout', 'remuk', 'jagoannya', 'umurku',
]);

const isKey = (w: string): boolean => KEYWORDS.has(w.toLowerCase().replace(/[^a-z]/g, ''));

const parse = (): CapWord[] => {
  const out: CapWord[] = [];
  const blocks = SRT_RAW.trim().split(/\r?\n\s*\r?\n/);
  for (const block of blocks) {
    const lines = block.split(/\r?\n/);
    const timeLine = lines[1] ?? '';
    const [a, b] = timeLine.split('-->').map((s) => toSec(s.trim()));
    const words = normalize(lines.slice(2).join(' ')).split(' ').filter(Boolean);
    const total = words.reduce((sum, w) => sum + w.length, 0);
    let cursor = a;
    for (const w of words) {
      const d = ((b - a) * w.length) / total;
      out.push({text: w, start: toFrame(cursor), end: toFrame(cursor + d), key: isKey(w)});
      cursor += d;
    }
  }
  return out;
};

export const CAPTION_WORDS: CapWord[] = parse();

/** Kelompokkan jadi frasa pendek (maks 4 kata, tampil maksimal 2 baris). */
const buildChunks = (): CapChunk[] => {
  const chunks: CapChunk[] = [];
  let cur: CapWord[] = [];
  const flush = () => {
    if (cur.length) {
      chunks.push({start: cur[0].start, end: cur[cur.length - 1].end, words: cur});
      cur = [];
    }
  };
  for (const w of CAPTION_WORDS) {
    cur.push(w);
    const endSentence = /[.?!]["']?$/.test(w.text);
    const endComma = /,["']?$/.test(w.text) && cur.length >= 2;
    if (cur.length >= 4 || endSentence || endComma) flush();
  }
  flush();
  // tahan frasa sampai frasa berikutnya mulai (jika jedanya pendek)
  for (let i = 0; i < chunks.length; i++) {
    const next = chunks[i + 1];
    const hold = chunks[i].end + 8;
    chunks[i].end = next ? Math.min(Math.max(chunks[i].end, hold), next.start) : hold;
  }
  return chunks;
};

export const CHUNKS: CapChunk[] = buildChunks();
