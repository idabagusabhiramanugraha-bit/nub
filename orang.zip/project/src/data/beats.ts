import {FPS} from './layout';

/**
 * Batas beat (detik) diturunkan dari SRT (kata dibagi proporsional).
 * SINKRONISASI FINAL MENUNGGU public/narasi.mp3 -> geser angka di sini bila perlu.
 */
export type Beat = {id: number; title: string; start: number; end: number; from: number; dur: number};

const RAW: Array<[number, string, number, number]> = [
  [1, 'Hook pertanyaan', 0, 2.0],
  [2, 'Jatuh sampai berdarah', 2.0, 5.0],
  [3, 'Sok kuat', 5.0, 7.1],
  [4, 'Tiba-tiba demam', 7.1, 9.2],
  [5, 'Manja saat demam', 9.2, 15.3],
  [6, 'Drama umur nggak panjang', 15.3, 19.0],
  [7, 'Kontras dengan kemarin', 19.0, 21.8],
  [8, 'Surat wasiat', 21.8, 25.4],
  [9, 'Penjelasan', 25.4, 35.9],
  [10, 'Mental jagoan logout', 35.9, 42.4],
  [11, 'Kembali percaya diri', 42.4, 44.2],
  [12, 'Ending komedi', 44.2, 46.0],
];

export const BEATS: Beat[] = RAW.map(([id, title, start, end]) => {
  const from = Math.round(start * FPS);
  const dur = Math.round(end * FPS) - from;
  return {id, title, start, end, from, dur};
});

export const TOTAL_FRAMES = BEATS[BEATS.length - 1].from + BEATS[BEATS.length - 1].dur; // 1380

/* ---- Saklar aset audio (ubah ke true setelah file ada di /public) ---- */
export const HAS_AUDIO = false; // public/narasi.mp3
export const HAS_SFX = false; // public/sounds/*.mp3 (lihat README)
export const HAS_MUSIC = false; // public/sounds/music.mp3

export type Sfx = {t: number; file: string; v?: number; len?: number};

/** Jadwal SFX (detik absolut). Nama file ada di public/sounds/. */
export const SFX: Sfx[] = [
  {t: 0.3, file: 'pop.mp3'},
  {t: 0.0, file: 'whoosh.mp3'},
  {t: 0.45, file: 'impact.mp3', v: 0.6},
  {t: 2.7, file: 'fall.mp3'},
  {t: 2.72, file: 'thud.mp3'},
  {t: 2.78, file: 'dust.mp3', v: 0.5},
  {t: 5.3, file: 'whoosh.mp3'},
  {t: 5.4, file: 'pop.mp3'},
  {t: 5.6, file: 'sting.mp3', v: 0.6},
  {t: 7.1, file: 'whoosh.mp3'},
  {t: 7.6, file: 'beep.mp3', v: 0.5},
  {t: 7.7, file: 'hit.mp3', v: 0.5},
  {t: 9.8, file: 'rustle.mp3', v: 0.6},
  {t: 11.0, file: 'shiver.mp3', v: 0.5},
  {t: 15.8, file: 'violin.mp3', v: 0.5, len: 3},
  {t: 18.0, file: 'sigh.mp3', v: 0.6},
  {t: 19.0, file: 'rewind.mp3', v: 0.6},
  {t: 19.7, file: 'motor.mp3', v: 0.5},
  {t: 20.5, file: 'laugh.mp3', v: 0.5},
  {t: 21.8, file: 'paper.mp3', v: 0.6},
  {t: 22.3, file: 'boom.mp3', v: 0.7},
  {t: 25.4, file: 'pop.mp3'},
  {t: 28.2, file: 'pop.mp3'},
  {t: 31.4, file: 'pop.mp3'},
  {t: 37.0, file: 'error.mp3', v: 0.5},
  {t: 41.7, file: 'powerdown.mp3', v: 0.7},
  {t: 41.9, file: 'bass.mp3', v: 0.8},
  {t: 42.4, file: 'whoosh.mp3'},
  {t: 42.6, file: 'sparkle.mp3'},
  {t: 43.1, file: 'sting.mp3', v: 0.6},
  {t: 44.2, file: 'cartoon-laugh.mp3', len: 1.8},
  {t: 44.3, file: 'final-impact.mp3', v: 0.8},
];

/** Volume musik latar: rendah di bawah narasi, hening 0,3 dtk sebelum "logout". */
export const musicVolume = (frame: number): number => {
  if (frame >= 1245 && frame < 1257) return 0;
  const fever = frame >= 213 && frame < 1272;
  return fever ? 0.08 : 0.12;
};
