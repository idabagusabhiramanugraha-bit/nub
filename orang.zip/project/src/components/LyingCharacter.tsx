import React from 'react';
import {C} from '../styles/theme';
import {Expression, Head, Thermometer} from './CharacterExpressions';

type Props = {
  cx?: number;
  cy?: number;
  sc?: number;
  e: Expression;
  talk?: number;
  blush?: boolean;
  blanketY: number;
  tilt?: number;
  headDy?: number;
  shiver?: number;
  f?: number;
  thermo?: boolean;
  hand?: {x: number; y: number} | null;
  shades?: boolean;
  children?: React.ReactNode; // digambar paling atas (mis. surat)
};

/** Karakter berbaring: bantal, hoodie, kepala, selimut, tangan. Semua lapisan terpisah. */
export const LyingCharacter: React.FC<Props> = ({
  cx = 480, cy = 1040, sc = 1, e, talk = 1, blush = true, blanketY, tilt = -6, headDy = 0, shiver = 0, f = 0,
  thermo = false, hand = null, shades = false, children,
}) => {
  const sx = Math.sin(f * 2.2) * shiver * 4;
  const sy = Math.cos(f * 2.9) * shiver * 2;
  const by = blanketY + sy;
  const hy = cy + headDy;
  const o = C.outline;
  return (
    <g transform={`translate(${sx},0)`}>
      {/* bantal */}
      <rect x={cx - 560 * sc} y={hy - 60 * sc} width={400 * sc} height={380 * sc} rx={100} fill={C.pillowBlue} stroke={o} strokeWidth={7} />
      <rect x={cx - 440 * sc} y={hy - 170 * sc} width={880 * sc} height={440 * sc} rx={120} fill={C.pillow} stroke={o} strokeWidth={7} />
      <path d={`M${cx - 380 * sc},${hy + 200 * sc} Q${cx},${hy + 240 * sc} ${cx + 380 * sc},${hy + 200 * sc}`} stroke="#C9CCE0" strokeWidth={10} fill="none" strokeLinecap="round" />
      {/* hoodie di bahu */}
      <path d={`M${cx - 120 * sc},${hy + 110 * sc} Q${cx},${hy + 70 * sc} ${cx + 120 * sc},${hy + 110 * sc} Q${cx + 110 * sc},${hy + 40 * sc} ${cx},${hy + 40 * sc} Q${cx - 110 * sc},${hy + 40 * sc} ${cx - 120 * sc},${hy + 110 * sc} Z`} fill={C.hoodShade} stroke={o} strokeWidth={6} />
      <ellipse cx={cx} cy={hy + 175 * sc} rx={205 * sc} ry={95 * sc} fill={C.hood} stroke={o} strokeWidth={7} />
      <path d={`M${cx - 20},${hy + 130 * sc} L${cx - 26},${hy + 215 * sc} M${cx + 20},${hy + 130 * sc} L${cx + 26},${hy + 215 * sc}`} stroke="#fff" strokeWidth={7} strokeLinecap="round" />
      {/* kepala */}
      <g transform={`translate(${cx},${hy}) rotate(${tilt}) scale(${sc})`}>
        <Head e={e} talk={talk} blush={blush} shades={shades} />
        {thermo ? <Thermometer /> : null}
      </g>
      {/* selimut */}
      <path
        d={`M-300,${by} Q140,${by - 50} 440,${by - 8} T 760,${by - 12} T 1380,${by - 30} L1380,2300 L-300,2300 Z`}
        fill={C.blanket}
        stroke={o}
        strokeWidth={8}
        strokeLinejoin="round"
      />
      <path d={`M-100,${by + 110} Q300,${by + 70} 620,${by + 120} T 1200,${by + 100}`} stroke={C.blanketHi} strokeWidth={10} fill="none" strokeLinecap="round" />
      <path d={`M-100,${by + 260} Q300,${by + 220} 620,${by + 270} T 1200,${by + 250}`} stroke={C.blanketHi} strokeWidth={10} fill="none" strokeLinecap="round" />
      {/* tangan */}
      {hand ? (
        <g>
          <path d={`M${hand.x + 110},${by + 80} Q${hand.x + 80},${hand.y + 90} ${hand.x},${hand.y}`} stroke={o} strokeWidth={20} fill="none" strokeLinecap="round" />
          <circle cx={hand.x} cy={hand.y} r={27} fill={o} />
          <circle cx={hand.x - 22} cy={hand.y - 14} r={11} fill={o} />
        </g>
      ) : null}
      {children}
    </g>
  );
};
