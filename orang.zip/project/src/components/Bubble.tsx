import React from 'react';
import {C, FONT} from '../styles/theme';
import {usePop} from './anim';

type Props = {
  x: number;
  y: number;
  w: number;
  h?: number;
  at: number;
  variant?: 'round' | 'burst' | 'sticker';
  tail?: 'down' | 'left' | 'right' | null;
  tailPos?: number;
  fs?: number;
  rot?: number;
  children?: React.ReactNode;
};

const burstPoints = (w: number, h: number, n = 14): string => {
  const pts: string[] = [];
  for (let i = 0; i < n * 2; i++) {
    const a = (i / (n * 2)) * Math.PI * 2;
    const k = i % 2 === 0 ? 1 : 0.8;
    pts.push(`${(w / 2 + Math.cos(a) * (w / 2 - 6) * k).toFixed(1)},${(h / 2 + Math.sin(a) * (h / 2 - 6) * k).toFixed(1)}`);
  }
  return pts.join(' ');
};

/** Balon teks (bagian dari cerita, bukan header). */
export const Bubble: React.FC<Props> = ({x, y, w, h = 300, at, variant = 'round', tail = 'down', tailPos = 30, fs = 64, rot = 0, children}) => {
  const p = usePop(at);
  if (p <= 0.001) return null;
  const common: React.CSSProperties = {
    position: 'absolute',
    left: x,
    top: y,
    width: w,
    fontFamily: FONT,
    fontWeight: 900,
    fontSize: fs,
    lineHeight: 1.08,
    textAlign: 'center',
    color: C.outline,
    transform: `scale(${p}) rotate(${rot}deg)`,
    transformOrigin: '50% 60%',
  };
  if (variant === 'burst') {
    return (
      <div style={{...common, height: h, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
        <svg width={w} height={h} style={{position: 'absolute', left: 0, top: 0}}>
          <polygon points={burstPoints(w, h)} fill={C.yellow} stroke={C.outline} strokeWidth={8} strokeLinejoin="round" />
        </svg>
        <div style={{position: 'relative', padding: '0 70px'}}>{children}</div>
      </div>
    );
  }
  const bg = variant === 'sticker' ? C.yellow : '#fff';
  const tailStyle: React.CSSProperties = {
    position: 'absolute',
    width: 44,
    height: 44,
    background: bg,
    transform: 'rotate(45deg)',
  };
  if (tail === 'down') Object.assign(tailStyle, {left: `${tailPos}%`, bottom: -25, borderRight: `8px solid ${C.outline}`, borderBottom: `8px solid ${C.outline}`});
  if (tail === 'left') Object.assign(tailStyle, {left: -25, top: `${tailPos}%`, borderLeft: `8px solid ${C.outline}`, borderBottom: `8px solid ${C.outline}`});
  if (tail === 'right') Object.assign(tailStyle, {right: -25, top: `${tailPos}%`, borderRight: `8px solid ${C.outline}`, borderTop: `8px solid ${C.outline}`});
  return (
    <div
      style={{
        ...common,
        background: bg,
        border: `8px solid ${C.outline}`,
        borderRadius: 64,
        padding: '26px 38px',
        boxSizing: 'border-box',
      }}
    >
      {children}
      {tail ? <div style={tailStyle} /> : null}
    </div>
  );
};

/** Teks besar bergaya komik (HAHAHA!, !!!). */
export const BigText: React.FC<{
  x: number; y: number; w: number; at: number; fs: number; color?: string; rot?: number; children?: React.ReactNode;
}> = ({x, y, w, at, fs, color = '#fff', rot = 0, children}) => {
  const p = usePop(at, 7);
  if (p <= 0.001) return null;
  const o = C.outline;
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        width: w,
        textAlign: 'center',
        fontFamily: FONT,
        fontWeight: 900,
        fontSize: fs,
        lineHeight: 1,
        color,
        textShadow: `-6px -6px 0 ${o},6px -6px 0 ${o},-6px 6px 0 ${o},6px 6px 0 ${o},0 9px 0 ${o},0 -9px 0 ${o},9px 0 0 ${o},-9px 0 0 ${o},0 14px 0 rgba(0,0,0,0.35)`,
        transform: `scale(${p}) rotate(${rot}deg)`,
        transformOrigin: '50% 50%',
      }}
    >
      {children}
    </div>
  );
};
