import React from 'react';
import {H, W} from '../data/layout';

export const Stage: React.FC<{children?: React.ReactNode}> = ({children}) => (
  <svg
    width={W}
    height={H}
    viewBox={`0 0 ${W} ${H}`}
    style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}}
  >
    {children}
  </svg>
);
