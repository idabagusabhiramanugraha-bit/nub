import React from 'react';
import {Audio, Sequence, staticFile} from 'remotion';
import {HAS_MUSIC, HAS_SFX, SFX, musicVolume} from '../data/beats';
import {FPS} from '../data/layout';

/** SFX + musik latar. Aktif hanya jika file ada (lihat saklar HAS_* di data/beats.ts). */
export const SoundEffects: React.FC = () => (
  <>
    {HAS_SFX
      ? SFX.map((s, i) => (
          <Sequence key={i} from={Math.round(s.t * FPS)} durationInFrames={Math.round((s.len ?? 1.5) * FPS)}>
            <Audio src={staticFile(`sounds/${s.file}`)} volume={s.v ?? 0.7} />
          </Sequence>
        ))
      : null}
    {HAS_MUSIC ? <Audio src={staticFile('sounds/music.mp3')} volume={(f: number) => musicVolume(f)} loop /> : null}
  </>
);
