import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from '../styles/theme';
import {usePop} from './anim';

export const Star: React.FC<{x: number; y: number; s?: number; at?: number; phase?: number; fill?: string}> = ({
  x, y, s = 30, at = 0, phase = 0, fill = C.yellow,
}) => {
  const p = usePop(at);
  const f = useCurrentFrame();
  const tw = 1 + 0.25 * Math.sin(f * 0.3 + phase);
  return (
    <g transform={`translate(${x},${y}) scale(${p * tw})`}>
      <path
        d={`M0,${-s} Q0,0 ${s},0 Q0,0 0,${s} Q0,0 ${-s},0 Q0,0 0,${-s} Z`}
        fill={fill}
        stroke={C.outline}
        strokeWidth={3}
        strokeLinejoin="round"
      />
    </g>
  );
};

export const Dust: React.FC<{x: number; y: number; at: number}> = ({x, y, at}) => {
  const f = useCurrentFrame() - at;
  if (f < 0 || f > 30) return null;
  const t = f / 30;
  return (
    <g opacity={1 - t}>
      {[-1, -0.5, 0, 0.5, 1].map((d, i) => (
        <circle
          key={i}
          cx={x + d * (60 + 120 * t)}
          cy={y - (i % 2) * 18 - 50 * t}
          r={18 + 40 * t}
          fill="#E4DFD3"
          stroke={C.outline}
          strokeWidth={4}
        />
      ))}
    </g>
  );
};

export const Steam: React.FC<{x: number; y: number}> = ({x, y}) => {
  const f = useCurrentFrame();
  return (
    <g>
      {[0, 1, 2].map((i) => {
        const p = ((f * 1.2 + i * 20) % 60) / 60;
        return (
          <circle
            key={i}
            cx={x + Math.sin(p * 6 + i) * 18}
            cy={y - p * 160}
            r={22 + p * 30}
            fill="#fff"
            opacity={0.85 * (1 - p)}
            stroke={C.outline}
            strokeWidth={4 * (1 - p)}
          />
        );
      })}
    </g>
  );
};

export const HeatLines: React.FC<{x: number; y: number}> = ({x, y}) => {
  const f = useCurrentFrame();
  const wob = Math.sin(f * 0.3) * 6;
  return (
    <g stroke={C.red} strokeWidth={9} fill="none" strokeLinecap="round">
      {[0, 34, 68].map((dx, i) => (
        <path
          key={dx}
          d={`M${x + dx},${y} q16,-24 0,-48 q-16,-24 0,-48`}
          transform={`translate(0,${wob * (i + 1) * 0.4})`}
        />
      ))}
    </g>
  );
};

export const SweatDrop: React.FC<{x: number; y: number; at?: number}> = ({x, y, at = 0}) => {
  const p = usePop(at);
  return (
    <g transform={`translate(${x},${y}) scale(${p})`}>
      <path d="M0,-26 Q22,6 0,18 Q-22,6 0,-26 Z" fill="#8FD3FF" stroke={C.outline} strokeWidth={4} strokeLinejoin="round" />
    </g>
  );
};

export const SpeedLines: React.FC<{cx: number; cy: number; count?: number; r0: number; r1: number; color?: string}> = ({
  cx, cy, count = 18, r0, r1, color = '#fff',
}) => {
  const f = useCurrentFrame();
  return (
    <g stroke={color} strokeWidth={7} strokeLinecap="round" opacity={0.85}>
      {Array.from({length: count}).map((_, i) => {
        const a = (i / count) * Math.PI * 2 + (f % 2) * 0.03;
        const k = 0.85 + 0.15 * Math.sin(i * 12.9898 + f * 0.7);
        return (
          <line
            key={i}
            x1={cx + Math.cos(a) * r0}
            y1={cy + Math.sin(a) * r0}
            x2={cx + Math.cos(a) * r1 * k}
            y2={cy + Math.sin(a) * r1 * k}
          />
        );
      })}
    </g>
  );
};
