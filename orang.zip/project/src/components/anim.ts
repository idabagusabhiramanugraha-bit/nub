import {Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';

/** Nilai pop 0..~1.1 (overshoot) mulai dari frame `at`. */
export const usePop = (at: number, damping = 9): number => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (frame < at) return 0;
  return spring({frame: frame - at, fps, config: {damping, stiffness: 170, mass: 0.6}});
};

/** Segmen 0..1 antara frame a dan b (easing out). */
export const seg = (f: number, a: number, b: number): number =>
  interpolate(f, [a, b], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });

export const clamp = {extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const};

/** Getaran deterministik. */
export const wob = (f: number, speed: number, amp: number, phase = 0): number =>
  Math.sin(f * speed + phase) * amp;
