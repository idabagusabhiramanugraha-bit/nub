import React from 'react';
import {C} from '../styles/theme';

const BARS = [
  [0, 18, 760], [40, 26, 980], [90, 14, 640], [130, 22, 1120], [190, 16, 820], [230, 24, 560],
  [830, 20, 700], [870, 14, 1040], [920, 26, 860], [970, 16, 1160], [1010, 22, 620], [1050, 18, 940],
];

/** Kamar dingin untuk adegan demam. Digambar di dalam <svg> induk. */
export const BedroomScene: React.FC<{stripes?: boolean; warm?: boolean}> = ({stripes = false, warm = false}) => {
  const o = C.outline;
  return (
    <g>
      <defs>
        <linearGradient id="wallG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={warm ? '#7B7FB5' : '#5A6094'} />
          <stop offset="1" stopColor={warm ? '#4F5486' : '#363A62'} />
        </linearGradient>
        <radialGradient id="vigG" cx="0.5" cy="0.5" r="0.75">
          <stop offset="0.45" stopColor="#0A0A1E" stopOpacity="0" />
          <stop offset="1" stopColor="#0A0A1E" stopOpacity="0.6" />
        </radialGradient>
      </defs>
      <rect x={-400} y={-400} width={1880} height={2700} fill="url(#wallG)" />
      {/* jendela + tirai */}
      <rect x={90} y={330} width={280} height={420} fill="#8FA2D8" stroke={o} strokeWidth={8} />
      <path d="M230,330 L230,750 M90,540 L370,540" stroke={o} strokeWidth={7} />
      <path d="M40,300 L150,300 L120,780 L40,780 Z" fill="#3A3A6E" stroke={o} strokeWidth={6} />
      <path d="M420,300 L310,300 L340,780 L420,780 Z" fill="#3A3A6E" stroke={o} strokeWidth={6} />
      {/* meja kecil, gelas air, termometer */}
      <rect x={820} y={900} width={260} height={30} rx={6} fill="#6B5B7B" stroke={o} strokeWidth={6} />
      <rect x={840} y={930} width={24} height={200} fill="#5A4B6B" stroke={o} strokeWidth={5} />
      <rect x={1040} y={930} width={24} height={200} fill="#5A4B6B" stroke={o} strokeWidth={5} />
      <rect x={880} y={810} width={70} height={90} rx={10} fill="#CFE8FF" opacity={0.85} stroke={o} strokeWidth={6} />
      <rect x={886} y={850} width={58} height={44} rx={6} fill="#8EC8F5" />
      <path d="M985,885 L1050,850" stroke={o} strokeWidth={18} strokeLinecap="round" />
      <path d="M985,885 L1050,850" stroke="#EAF5FF" strokeWidth={9} strokeLinecap="round" />
      {stripes
        ? BARS.map(([x, w, h], i) => (
            <rect key={i} x={x} y={-100} width={w} height={h} rx={w / 2} fill="#14162E" opacity={0.5} />
          ))
        : null}
      <rect x={-400} y={-400} width={1880} height={2700} fill="url(#vigG)" />
    </g>
  );
};
