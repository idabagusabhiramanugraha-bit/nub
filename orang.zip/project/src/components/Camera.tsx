import React from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';
import {H, W} from '../data/layout';

export type KF = {f: number; z: number; x?: number; y?: number; r?: number};

type Props = {
  kf: KF[];
  shake?: {at: number; amp: number; len?: number};
  children?: React.ReactNode;
};

/** Kamera virtual: zoom, pan (titik fokus), tilt, dan shake. Deterministik. */
export const Camera: React.FC<Props> = ({kf, shake, children}) => {
  const frame = useCurrentFrame();
  const list = kf.length === 1 ? [kf[0], {...kf[0], f: kf[0].f + 1}] : kf;
  const input = list.map((k) => k.f);
  const opt = {
    extrapolateLeft: 'clamp' as const,
    extrapolateRight: 'clamp' as const,
    easing: Easing.inOut(Easing.cubic),
  };
  const z = interpolate(frame, input, list.map((k) => k.z), opt);
  const x = interpolate(frame, input, list.map((k) => k.x ?? W / 2), opt);
  const y = interpolate(frame, input, list.map((k) => k.y ?? H / 2), opt);
  const r = interpolate(frame, input, list.map((k) => k.r ?? 0), opt);
  let dx = 0;
  let dy = 0;
  if (shake && frame >= shake.at) {
    const len = shake.len ?? 10;
    const d = Math.max(0, 1 - (frame - shake.at) / len);
    dx = Math.sin(frame * 2.7) * shake.amp * d;
    dy = Math.cos(frame * 3.3) * shake.amp * d;
  }
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        top: 0,
        width: W,
        height: H,
        transformOrigin: '0 0',
        transform: `translate(${W / 2 + dx}px, ${H / 2 + dy}px) rotate(${r}deg) scale(${z}) translate(${-x}px, ${-y}px)`,
      }}
    >
      {children}
    </div>
  );
};
