import React from 'react';
import {AbsoluteFill, Sequence, interpolate, useCurrentFrame} from 'remotion';
import {BEATS} from '../data/beats';
import {clamp} from './anim';

const fromOf = (id: number): number => BEATS.find((b) => b.id === id)?.from ?? 0;

/** Whip: panel warna meluncur melintasi layar. */
const Whip: React.FC<{color: string; len: number}> = ({color, len}) => {
  const f = useCurrentFrame();
  const x = interpolate(f, [0, len], [1200, -1200], clamp);
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', top: 0, left: x, width: 1200, height: 1920, background: `linear-gradient(90deg, transparent, ${color} 25%, ${color} 75%, transparent)`}} />
    </AbsoluteFill>
  );
};

/** Flash/smash cut: warna penuh yang cepat memudar. */
const Flash: React.FC<{color: string; len: number; peak: number}> = ({color, len, peak}) => {
  const f = useCurrentFrame();
  const o = interpolate(f, [0, 1, len], [peak, peak, 0], clamp);
  return <AbsoluteFill style={{background: color, opacity: o}} />;
};

/** Transisi tidak ramai: hanya di titik cerita yang butuh (whip, smash cut, jeda hitam sebelum punchline). */
export const Transitions: React.FC = () => (
  <>
    <Sequence from={fromOf(2) - 4} durationInFrames={9}><Whip color="#FFFFFF" len={9} /></Sequence>
    <Sequence from={fromOf(4)} durationInFrames={6}><Flash color="#FFFFFF" len={6} peak={0.9} /></Sequence>
    <Sequence from={fromOf(9) - 4} durationInFrames={9}><Whip color="#FFB703" len={9} /></Sequence>
    <Sequence from={fromOf(10)} durationInFrames={6}><Flash color="#000000" len={6} peak={1} /></Sequence>
    <Sequence from={fromOf(11) - 4} durationInFrames={4}><AbsoluteFill style={{background: '#000'}} /></Sequence>
    <Sequence from={fromOf(12)} durationInFrames={4}><Flash color="#FFFFFF" len={4} peak={0.7} /></Sequence>
  </>
);
