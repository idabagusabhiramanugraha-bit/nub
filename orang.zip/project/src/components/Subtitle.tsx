import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {CHUNKS} from '../data/captions';
import {LAYOUT} from '../data/layout';
import {C, FONT} from '../styles/theme';

const o = C.outline;
const STROKE = `-4px -4px 0 ${o},4px -4px 0 ${o},-4px 4px 0 ${o},4px 4px 0 ${o},0 6px 0 ${o},0 -6px 0 ${o},6px 0 0 ${o},-6px 0 0 ${o},0 9px 10px rgba(0,0,0,0.4)`;

/** Subtitle per frasa, word-pop, kata kunci kuning, di area aman. */
export const Subtitle: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const L = LAYOUT.subtitle;
  const chunk = CHUNKS.find((c) => frame >= c.start && frame < c.end);
  if (!chunk) return null;
  return (
    <div
      style={{
        position: 'absolute',
        left: L.x,
        top: L.y,
        width: L.w,
        height: L.h,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-start',
      }}
    >
      <div style={{display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '0 20px', maxWidth: L.w}}>
        {chunk.words.map((w, i) => {
          const started = frame >= w.start;
          const p = started ? spring({frame: frame - w.start, fps, config: {damping: 10, stiffness: 220, mass: 0.5}}) : 0;
          const active = started && frame < w.end;
          return (
            <span
              key={i}
              style={{
                fontFamily: FONT,
                fontWeight: 900,
                fontSize: 70,
                lineHeight: 1.12,
                color: w.key ? C.yellow : '#fff',
                textShadow: STROKE,
                opacity: started ? 1 : 0,
                transform: `scale(${(0.6 + 0.4 * p) * (active ? 1.08 : 1)})`,
                display: 'inline-block',
              }}
            >
              {w.text}
            </span>
          );
        })}
      </div>
    </div>
  );
};
