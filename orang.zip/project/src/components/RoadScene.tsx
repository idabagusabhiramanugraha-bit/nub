import React from 'react';
import {C} from '../styles/theme';

const FAR = [
  {x: -100, w: 260, h: 520}, {x: 200, w: 200, h: 700}, {x: 430, w: 300, h: 480}, {x: 760, w: 240, h: 640}, {x: 1030, w: 260, h: 560},
];
const NEAR = [
  {x: -60, w: 300, h: 420}, {x: 300, w: 260, h: 560}, {x: 600, w: 320, h: 380}, {x: 950, w: 280, h: 500},
];
const GROUND = 1180;

const Windows: React.FC<{x: number; w: number; h: number; col: string}> = ({x, w, h, col}) => {
  const cols = Math.floor((w - 30) / 54);
  const rows = Math.floor((h - 40) / 80);
  const out: React.ReactNode[] = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      out.push(<rect key={`${r}-${c}`} x={x + 24 + c * 54} y={GROUND - h + 30 + r * 80} width={30} height={48} rx={4} fill={col} opacity={0.85} />);
    }
  }
  return <g>{out}</g>;
};

/** Jalanan siang hari: langit, gedung (parallax 2 lapis), pohon, trotoar, aspal. Digambar dalam <svg> induk. */
export const RoadScene: React.FC<{t: number; blur?: boolean}> = ({t, blur = false}) => {
  const far = -t * 0.25;
  const near = -t * 0.6;
  return (
    <g>
      <defs>
        <linearGradient id="skyG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#5FB8FF" />
          <stop offset="1" stopColor="#D6EEFF" />
        </linearGradient>
        <filter id="rsBlur"><feGaussianBlur stdDeviation="9" /></filter>
      </defs>
      <g filter={blur ? 'url(#rsBlur)' : undefined}>
        <rect x={-400} y={-400} width={1880} height={GROUND + 400} fill="url(#skyG)" />
        <circle cx={880} cy={330} r={95} fill="#FFF3B0" opacity={0.85} />
        <g transform={`translate(${far},0)`}>
          {FAR.map((b, i) => (
            <rect key={i} x={b.x} y={GROUND - b.h} width={b.w} height={b.h} fill="#A9C6E8" stroke={C.outline} strokeWidth={4} />
          ))}
        </g>
        <g transform={`translate(${near},0)`}>
          {NEAR.map((b, i) => (
            <g key={i}>
              <rect x={b.x} y={GROUND - b.h} width={b.w} height={b.h} fill="#7FA3CF" stroke={C.outline} strokeWidth={5} />
              <Windows x={b.x} w={b.w} h={b.h} col="#EAF6FF" />
            </g>
          ))}
          {[140, 930].map((x) => (
            <g key={x}>
              <rect x={x - 14} y={GROUND - 190} width={28} height={190} fill="#6B4A2E" stroke={C.outline} strokeWidth={5} />
              <circle cx={x} cy={GROUND - 250} r={96} fill="#4CAF50" stroke={C.outline} strokeWidth={6} />
              <circle cx={x - 50} cy={GROUND - 200} r={60} fill="#58BD5C" stroke={C.outline} strokeWidth={5} />
            </g>
          ))}
        </g>
        {/* trotoar */}
        <rect x={-400} y={GROUND} width={1880} height={170} fill="#CFC9BC" />
        {[0, 1, 2, 3, 4, 5, 6].map((i) => (
          <line key={i} x1={i * 200 - 100} y1={GROUND} x2={i * 200 - 160} y2={GROUND + 170} stroke="#B2AC9F" strokeWidth={4} />
        ))}
        <rect x={-400} y={GROUND + 170} width={1880} height={24} fill="#9E9A90" stroke={C.outline} strokeWidth={4} />
        {/* aspal */}
        <rect x={-400} y={GROUND + 194} width={1880} height={1100} fill="#565B68" />
        {[0, 1, 2, 3, 4].map((i) => (
          <rect key={i} x={i * 280 - 100} y={1700} width={160} height={22} rx={8} fill="#F2F2F2" />
        ))}
      </g>
    </g>
  );
};
