import React from 'react';
import {C} from '../styles/theme';

export type Expression = 'smug' | 'think' | 'pain' | 'sick' | 'weak' | 'dying' | 'shock' | 'tired' | 'laugh';

const S = {stroke: C.outline, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, fill: 'none'};

const Brow: React.FC<{a: [number, number]; b: [number, number]}> = ({a, b}) => (
  <path d={`M${a[0]},${a[1]} L${b[0]},${b[1]}`} {...S} strokeWidth={9} />
);

/** Mata setengah tertutup (lid datar di atas). */
const HalfEye: React.FC<{x: number}> = ({x}) => (
  <path
    d={`M${x - 17},-4 L${x + 17},-4 A17,14 0 0 1 ${x - 17},-4 Z`}
    fill={C.outline}
    stroke={C.outline}
    strokeWidth={4}
    strokeLinejoin="round"
  />
);

const Dot: React.FC<{x: number; y: number}> = ({x, y}) => <ellipse cx={x} cy={y} rx={9} ry={11} fill={C.outline} />;

const OpenMouth: React.FC<{cx: number; cy: number; rx: number; ry: number}> = ({cx, cy, rx, ry}) => (
  <g>
    <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill={C.mouth} />
    <ellipse cx={cx} cy={cy + ry * 0.45} rx={rx * 0.55} ry={ry * 0.42} fill={C.tongue} />
    <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill="none" stroke={C.outline} strokeWidth={7} />
  </g>
);

export const Face: React.FC<{e: Expression; talk?: number; blush?: boolean}> = ({e, talk = 1, blush = false}) => {
  const t = 0.45 + 0.55 * talk;
  let inner: React.ReactNode = null;
  switch (e) {
    case 'smug':
      inner = (
        <>
          <HalfEye x={-32} />
          <HalfEye x={32} />
          <Brow a={[-56, -26]} b={[-14, -20]} />
          <Brow a={[14, -32]} b={[56, -20]} />
          <path d="M-38,36 Q8,66 48,28" {...S} strokeWidth={8} />
        </>
      );
      break;
    case 'think':
      inner = (
        <>
          <Dot x={-28} y={-8} />
          <Dot x={36} y={-8} />
          <Brow a={[-58, -30]} b={[-14, -18]} />
          <Brow a={[14, -46]} b={[56, -34]} />
          <path d="M-18,48 L22,42" {...S} strokeWidth={8} />
        </>
      );
      break;
    case 'pain':
      inner = (
        <>
          <path d="M-55,-22 L-18,-6 L-55,10" {...S} strokeWidth={9} />
          <path d="M55,-22 L18,-6 L55,10" {...S} strokeWidth={9} />
          <OpenMouth cx={0} cy={46} rx={26} ry={22 * t} />
        </>
      );
      break;
    case 'sick':
      inner = (
        <>
          <HalfEye x={-32} />
          <HalfEye x={32} />
          <Brow a={[-56, -18]} b={[-16, -34]} />
          <Brow a={[16, -34]} b={[56, -18]} />
          <path d="M-22,50 Q-10,40 0,50 Q10,60 22,48" {...S} strokeWidth={7} />
        </>
      );
      break;
    case 'weak':
      inner = (
        <>
          <HalfEye x={-32} />
          <HalfEye x={32} />
          <Brow a={[-56, -18]} b={[-16, -34]} />
          <Brow a={[16, -34]} b={[56, -18]} />
          <OpenMouth cx={0} cy={50} rx={14} ry={10 * t} />
        </>
      );
      break;
    case 'dying':
      inner = (
        <>
          <HalfEye x={-32} />
          <HalfEye x={32} />
          <Brow a={[-58, -14]} b={[-14, -38]} />
          <Brow a={[14, -38]} b={[58, -14]} />
          <OpenMouth cx={0} cy={50} rx={25} ry={14 + 16 * t} />
        </>
      );
      break;
    case 'shock':
      inner = (
        <>
          <circle cx={-32} cy={-6} r={19} fill="#fff" stroke={C.outline} strokeWidth={6} />
          <circle cx={32} cy={-6} r={19} fill="#fff" stroke={C.outline} strokeWidth={6} />
          <circle cx={-30} cy={-4} r={6} fill={C.outline} />
          <circle cx={34} cy={-4} r={6} fill={C.outline} />
          <Brow a={[-58, -48]} b={[-14, -54]} />
          <Brow a={[14, -54]} b={[58, -48]} />
          <OpenMouth cx={0} cy={52} rx={30} ry={22 + 16 * t} />
        </>
      );
      break;
    case 'tired':
      inner = (
        <>
          <path d="M-50,-2 Q-32,10 -14,-2" {...S} strokeWidth={8} />
          <path d="M14,-2 Q32,10 50,-2" {...S} strokeWidth={8} />
          <Brow a={[-56, -20]} b={[-16, -32]} />
          <Brow a={[16, -32]} b={[56, -20]} />
          <OpenMouth cx={0} cy={50} rx={13} ry={8 * t + 3} />
        </>
      );
      break;
    case 'laugh':
      inner = (
        <>
          <path d="M-50,6 Q-32,-16 -14,6" {...S} strokeWidth={9} />
          <path d="M14,6 Q32,-16 50,6" {...S} strokeWidth={9} />
          <g transform={`translate(0,16) scale(1,${0.8 + 0.3 * t}) translate(0,-16)`}>
            <path d="M-52,16 Q0,100 52,16 Z" fill={C.mouth} stroke={C.outline} strokeWidth={7} strokeLinejoin="round" />
            <ellipse cx={0} cy={56} rx={22} ry={11} fill={C.tongue} />
          </g>
        </>
      );
      break;
  }
  return (
    <g>
      {blush ? (
        <>
          <ellipse cx={-58} cy={26} rx={20} ry={12} fill={C.blush} opacity={0.85} />
          <ellipse cx={58} cy={26} rx={20} ry={12} fill={C.blush} opacity={0.85} />
        </>
      ) : null}
      {inner}
    </g>
  );
};

const HAIR =
  'M-92,-18 L-108,-62 L-74,-52 L-92,-118 L-50,-92 L-46,-152 L-8,-106 L14,-168 L40,-108 L78,-150 L72,-86 L110,-98 L92,-38 Q62,-76 0,-78 Q-52,-76 -92,-18 Z';

type HeadProps = {e: Expression; talk?: number; blush?: boolean; shades?: boolean};

/** Kepala (pusat 0,0, radius 90): kepala bulat putih, rambut cokelat berduri, wajah. */
export const Head: React.FC<HeadProps> = ({e, talk = 1, blush = false, shades = false}) => (
  <g>
    <circle cx={0} cy={0} r={90} fill="#fff" stroke={C.outline} strokeWidth={8} />
    <path d="M-70,50 A90,90 0 0 0 50,76" stroke="#D5D8E6" strokeWidth={14} fill="none" strokeLinecap="round" opacity={0.8} />
    <Face e={e} talk={talk} blush={blush} />
    {shades ? (
      <g fill={C.outline} stroke={C.outline} strokeWidth={5} strokeLinejoin="round">
        <rect x={-68} y={-30} width={58} height={40} rx={14} />
        <rect x={10} y={-30} width={58} height={40} rx={14} />
        <path d="M-12,-18 L12,-18" strokeWidth={7} />
        <path d="M-68,-20 L-88,-28 M68,-20 L88,-28" strokeWidth={6} />
      </g>
    ) : null}
    <path d={HAIR} fill={C.hair} stroke={C.outline} strokeWidth={6} strokeLinejoin="round" />
    <g stroke={C.hairHi} strokeWidth={5} strokeLinecap="round" fill="none" opacity={0.9}>
      <path d="M-30,-100 L-30,-136" />
      <path d="M30,-98 L46,-126" />
      <path d="M-72,-68 L-84,-96" />
    </g>
  </g>
);

export const Thermometer: React.FC = () => (
  <g>
    <path d="M20,52 L150,100" stroke={C.outline} strokeWidth={26} strokeLinecap="round" />
    <path d="M20,52 L150,100" stroke="#EAF5FF" strokeWidth={14} strokeLinecap="round" />
    <path d="M92,76 L150,100" stroke={C.red} strokeWidth={14} strokeLinecap="round" />
    <circle cx={160} cy={104} r={13} fill={C.red} stroke={C.outline} strokeWidth={5} />
  </g>
);
