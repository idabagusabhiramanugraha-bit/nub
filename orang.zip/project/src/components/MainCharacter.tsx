import React from 'react';
import {C} from '../styles/theme';
import {Expression, Head, Thermometer} from './CharacterExpressions';

/** Pose numerik supaya bisa di-interpolasi mulus. Koordinat lokal, kaki di (0,0), naik = Y negatif. */
export type Pose = {aL: number[]; aR: number[]; lL: number[]; lR: number[]}; // arm [ex,ey,hx,hy], leg [kx,ky,fx,fy]
export type PoseName =
  | 'stand' | 'think' | 'headHand' | 'thumbs' | 'pointUp' | 'flail' | 'sit' | 'rise' | 'adjust' | 'pat' | 'ride';

const HIPS_A = {aL: [-125, -300, -78, -232], aR: [125, -300, 78, -232]};
const LEGS = {lL: [-30, -100, -36, 0], lR: [30, -100, 36, 0]};

export const POSES: Record<PoseName, Pose> = {
  stand: {...HIPS_A, ...LEGS},
  think: {aL: [-100, -290, 30, -300], aR: [125, -330, 22, -392], ...LEGS},
  headHand: {aL: HIPS_A.aL, aR: [160, -440, 66, -515], ...LEGS},
  thumbs: {aL: HIPS_A.aL, aR: [140, -380, 175, -450], ...LEGS},
  pointUp: {aL: HIPS_A.aL, aR: [125, -430, 150, -560], ...LEGS},
  flail: {aL: [-150, -440, -170, -540], aR: [150, -440, 170, -540], lL: [-60, -110, -85, -10], lR: [70, -120, 110, -30]},
  sit: {aL: [-150, -360, -152, -300], aR: [120, -290, 60, -185], lL: [-150, -290, -120, -195], lR: [120, -205, 240, -190]},
  rise: {aL: [-110, -290, -70, -190], aR: [110, -290, 70, -190], lL: [-40, -95, -38, 0], lR: [40, -95, 38, 0]},
  adjust: {aL: HIPS_A.aL, aR: [110, -420, 50, -482], ...LEGS},
  pat: {aL: [-120, -300, -60, -290], aR: HIPS_A.aR, ...LEGS},
  ride: {aL: [60, -345, 150, -290], aR: [80, -340, 150, -290], lL: [60, -150, 20, -80], lR: [70, -150, 30, -75]},
};

const mix = (a: number[], b: number[], t: number): number[] => a.map((v, i) => v + (b[i] - v) * t);

export const lerpPose = (a: Pose, b: Pose, t: number): Pose => {
  const k = Math.max(0, Math.min(1, t));
  return {aL: mix(a.aL, b.aL, k), aR: mix(a.aR, b.aR, k), lL: mix(a.lL, b.lL, k), lR: mix(a.lR, b.lR, k)};
};

export type MainCharacterProps = {
  x: number;
  y: number;
  scale?: number;
  rot?: number;
  sx?: number;
  sy?: number;
  pose?: Pose;
  expression: Expression;
  talk?: number;
  blush?: boolean;
  shades?: boolean;
  finger?: 'point' | 'thumb' | null;
  wound?: 'L' | 'R' | null;
  headTilt?: number;
  headDy?: number;
  shadow?: boolean;
  thermo?: boolean;
  flip?: boolean;
};

const O = C.outline;

export const MainCharacter: React.FC<MainCharacterProps> = ({
  x, y, scale = 1, rot = 0, sx = 1, sy = 1, pose = POSES.stand, expression, talk = 1, blush = false, shades = false,
  finger = null, wound = null, headTilt = 0, headDy = 0, shadow = true, thermo = false, flip = false,
}) => {
  const SL = [-72, -365];
  const SR = [72, -365];
  const leg = (h: number, l: number[]) => `M${h},-205 L${l[0]},${l[1]} L${l[2]},${l[3]}`;
  const arm = (s: number[], a: number[]) => `M${s[0]},${s[1]} Q${a[0]},${a[1]} ${a[2]},${a[3]}`;
  const knee = wound === 'L' ? pose.lL : wound === 'R' ? pose.lR : null;
  const hand = pose.aR;
  return (
    <g transform={`translate(${x},${y}) rotate(${rot}) scale(${scale * sx * (flip ? -1 : 1)},${scale * sy})`}>
      {shadow ? <ellipse cx={0} cy={4} rx={150} ry={20} fill="#000" opacity={0.18} /> : null}
      {/* kaki */}
      <path d={leg(-26, pose.lL)} stroke={O} strokeWidth={17} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <path d={leg(26, pose.lR)} stroke={O} strokeWidth={17} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <ellipse cx={pose.lL[2] - 12} cy={pose.lL[3] - 8} rx={30} ry={14} fill={O} />
      <ellipse cx={pose.lR[2] + 12} cy={pose.lR[3] - 8} rx={30} ry={14} fill={O} />
      {/* badan: hoodie */}
      <path d="M-82,-395 Q0,-418 82,-395 L100,-195 Q0,-175 -100,-195 Z" fill={C.hood} stroke={O} strokeWidth={7} strokeLinejoin="round" />
      <path d="M-98,-215 Q0,-190 98,-215 L100,-195 Q0,-175 -100,-195 Z" fill={C.hoodShade} opacity={0.8} />
      <path d="M-52,-290 Q0,-270 52,-290 L60,-232 Q0,-216 -60,-232 Z" fill={C.hoodShade} opacity={0.6} stroke={O} strokeWidth={5} strokeLinejoin="round" />
      <path d="M-16,-392 L-20,-318" stroke={O} strokeWidth={13} strokeLinecap="round" />
      <path d="M16,-392 L20,-318" stroke={O} strokeWidth={13} strokeLinecap="round" />
      <path d="M-16,-392 L-20,-318" stroke="#fff" strokeWidth={6} strokeLinecap="round" />
      <path d="M16,-392 L20,-318" stroke="#fff" strokeWidth={6} strokeLinecap="round" />
      {/* lengan */}
      <path d={arm(SL, pose.aL)} stroke={O} strokeWidth={15} fill="none" strokeLinecap="round" />
      <path d={arm(SR, pose.aR)} stroke={O} strokeWidth={15} fill="none" strokeLinecap="round" />
      <circle cx={pose.aL[2]} cy={pose.aL[3]} r={18} fill={O} />
      <circle cx={pose.aR[2]} cy={pose.aR[3]} r={18} fill={O} />
      {finger === 'point' ? (
        <path d={`M${hand[2]},${hand[3]} L${hand[2] + 6},${hand[3] - 48}`} stroke={O} strokeWidth={13} strokeLinecap="round" />
      ) : null}
      {finger === 'thumb' ? (
        <path d={`M${hand[2] - 4},${hand[3]} L${hand[2] - 4},${hand[3] - 36}`} stroke={O} strokeWidth={14} strokeLinecap="round" />
      ) : null}
      {/* lengan baju pendek */}
      <ellipse cx={-84} cy={-362} rx={30} ry={36} fill={C.hood} stroke={O} strokeWidth={6} />
      <ellipse cx={84} cy={-362} rx={30} ry={36} fill={C.hood} stroke={O} strokeWidth={6} />
      {/* luka lutut (kartun, bukan realistis) */}
      {knee ? (
        <g transform={`translate(${knee[0]},${knee[1]})`}>
          <circle r={24} fill="#fff" stroke={O} strokeWidth={4} />
          <path d="M-14,-10 L10,14 M-4,-16 L16,6 M-16,2 L2,18" stroke={C.blood} strokeWidth={6} strokeLinecap="round" />
          <path d="M6,18 Q20,40 6,48 Q-8,40 6,18 Z" fill={C.blood} stroke={O} strokeWidth={3} />
        </g>
      ) : null}
      {/* tudung di belakang leher */}
      <path d="M-70,-392 Q0,-345 70,-392 Q60,-430 0,-428 Q-60,-430 -70,-392 Z" fill={C.hoodShade} stroke={O} strokeWidth={6} strokeLinejoin="round" />
      {/* kepala */}
      <g transform={`translate(0,${-478 + headDy}) rotate(${headTilt})`}>
        <Head e={expression} talk={talk} blush={blush} shades={shades} />
        {thermo ? <Thermometer /> : null}
      </g>
    </g>
  );
};
