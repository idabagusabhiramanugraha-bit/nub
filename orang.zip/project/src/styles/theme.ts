export const C = {
  outline: '#0B0B10',
  hair: '#4A2C1A',
  hairHi: '#7A4B2E',
  hood: '#D9DBE3',
  hoodShade: '#B8BBC8',
  white: '#FFFFFF',
  blush: '#F5A3B5',
  red: '#D7263D',
  yellow: '#FFD23F',
  blood: '#C1121F',
  mouth: '#B3202A',
  tongue: '#F07C8A',
  blanket: '#56608F',
  blanketHi: '#7480B8',
  pillow: '#E9EBF6',
  pillowBlue: '#8C93B8',
};

export const FONT = "'Baloo 2','Arial Black',Impact,'Segoe UI',sans-serif";
