# Cowok: Tahan Luka vs Tahan Demam (Remotion, 1080x1920, 30 fps)

Video komedi vertikal ±46 detik (1380 frame). Tanpa header; seluruh layar untuk cerita.

## STATUS JUJUR (baca dulu)
- Kode sudah lolos pengecekan TypeScript terhadap stub tipe, dan 13 frame dari seluruh 12 beat sudah dirender sebagai gambar uji
  (karakter, adegan, subtitle terlihat benar).
- **Render MP4 penuh BELUM pernah dijalankan** (lingkungan pembuatan tidak punya internet, jadi `npm install` dan
  Remotion asli tidak bisa dipasang). Jalankan `npm run dev` dulu dan periksa di preview.
- `public/narasi.mp3` **belum ada**. Timing subtitle dan batas beat masih **sementara**, diturunkan dari SRT
  (kata dibagi proporsional per jumlah karakter). Setelah audio ada: nyalakan `HAS_AUDIO`, lalu cek sinkronisasi.
- SFX dan musik belum disertakan (tidak mengarang file audio). Jadwal SFX sudah ada di `src/data/beats.ts`.

## Langkah di Windows
1. Instal **Node.js LTS** dari nodejs.org (centang opsi default, klik Next sampai selesai).
2. **Ekstrak ZIP** (klik kanan > Extract All).
3. **Buka folder proyek** (yang berisi `package.json`).
4. Klik kolom alamat folder, ketik `cmd`, tekan Enter: terminal terbuka di folder itu.
5. Jalankan `npm install` (butuh internet, tunggu beberapa menit).
6. Taruh `narasi.mp3` di folder `public/`, lalu di `src/data/beats.ts` ubah `HAS_AUDIO = true`.
7. Jalankan `npm run dev`. Browser membuka **Remotion Studio** (preview). Geser timeline untuk melihat tiap beat.
8. Jika subtitle terlambat/terlalu cepat: ubah `AUDIO_OFFSET` (detik) di `src/data/captions.ts`.
   Untuk presisi, ganti isi `SRT_RAW` dengan SRT hasil transkripsi `narasi.mp3`.
   Batas beat ada di `src/data/beats.ts` (tabel `RAW`, dalam detik).
9. Jalankan `npm run render`.
10. Hasil: `out/video.mp4` di dalam folder proyek.

Cek tipe: `npm run typecheck`. Satu frame uji: `npm run still` (hasil `out/frame.png`).

## Struktur
- `src/data/beats.ts` batas 12 beat, saklar audio, jadwal SFX, volume musik
- `src/data/captions.ts` parser SRT, `AUDIO_OFFSET`, subtitle per frasa (`Math.round(t * fps)`)
- `src/data/layout.ts` tabel koordinat dan area aman
- `src/beats/*` satu komponen per adegan (Hook, Injury, Fever, Blanket, Will, Flashback, Explanation, Logout, Ending)
- `src/components/*` MainCharacter, CharacterExpressions, LyingCharacter, RoadScene, BedroomScene, Camera, Bubble, FX, Subtitle, SoundEffects, Transitions
- `captions.srt` SRT asli (juga di `public/captions.srt`)

## Catatan desain
- Karakter digambar sebagai SVG berlapis (kepala, rambut, wajah, hoodie, lengan, kaki) mengikuti character sheet; gambar referensi tidak dipakai sebagai background.
- Semua animasi memakai `useCurrentFrame`, `interpolate`, `spring` (deterministik); tanpa CSS animation dan `setTimeout`.
- Subtitle menampilkan "nggak" dan "logout" sesuai naskah final (SRT menulis "enggak" dan "lock out").
- Beat 07 memakai split atas-bawah (bukan kiri-kanan) karena kanvas vertikal, dan Beat 11 membuka dengan 12 frame panel 11 (tidur + hati) sebelum smash cut.
- Dependensi memakai `^4.0.250`. Jika Remotion memberi peringatan versi tidak sama, samakan versi `remotion` dan `@remotion/cli` persis.
