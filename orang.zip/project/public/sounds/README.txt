Taruh file audio di folder ini (format .mp3), lalu ubah HAS_SFX / HAS_MUSIC menjadi true di src/data/beats.ts.

SFX (nama file harus persis):
pop, whoosh, impact, fall, thud, dust, sting, beep, hit, rustle, shiver, violin, sigh,
rewind, motor, laugh, paper, boom, error, powerdown, bass, sparkle, cartoon-laugh, final-impact
(contoh: pop.mp3, whoosh.mp3, ...)

Musik latar (opsional): music.mp3  -> komedi ringan, tempo ~120 BPM, di-loop otomatis.
Pakai audio bebas hak cipta / berlisensi yang boleh dipakai di YouTube, TikTok, dan Reels.
